<div class="wz-products columns">
	<div class="wz-item-container">
		<div class="item-container">
			<div class="item-inner-container">
				<div class="item-head-image">
					<img src="{{}}" width="150" height="150">
				</div>
				<div class="item-topic-wrapper">
					<div class="item-topic">({note}}</div>
				</div>
				<div class="item-content-body">
					<p>{{}}</p>
				</div>
			</div>	
		</div>
	</div>
</div>