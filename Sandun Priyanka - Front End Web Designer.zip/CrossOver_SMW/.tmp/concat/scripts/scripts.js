
(function(){

'use strict';

// declare Autherntication module in here.
angular.module('Authentication', []);

var appModule = angular.module('crossOverSmwApp', [
    'Authentication',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
]);

appModule.config(['$routeProvider',
  function($routeProvider,$scope) {
    $routeProvider.
      when('/', {
        controller: 'LoginController',
        templateUrl: 'views/login.html'
      }).
      when('/home', {
        controller: 'HomeController',
        templateUrl: 'views/home.html'
      }).
      when('/about', {
        controller: 'about',
        templateUrl: 'views/about.html'
      }).otherwise({ redirectTo: '/' });
  }]);

appModule.run(['$rootScope', '$location', '$cookies', '$http',
    function ($rootScope, $location, $cookies, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookies.get('globals') || {};

        if ($rootScope.globals.currentUser) {
            appModule.value('username', $rootScope.globals.currentUser.username);
            appModule.value('authdata', $rootScope.globals.currentUser.authdata);
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }
 
        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in
            console.log($rootScope.globals.currentUser);
            if ($location.path() !== '/' && !$rootScope.globals.currentUser) {
                $location.path('/');
            }
        });
    }]);


})();







'use strict'
angular.module('Authentication')
.controller('LoginController', 
	['$scope','$rootScope','$location','LoginAuthService', 
		function($scope,$rootScope,$location,LoginAuthService){
			LoginAuthService.ClearCredentials();

			$scope.login = function(){
				LoginAuthService.Login($scope.username,$scope.password,function(response){


   					if(response.loginSucceeded){
              console.log("inside");
   						LoginAuthService.SetCredentials($scope.username,  response.sessionId);

   						$location.path('/home');
   					}else{
   						$scope.error = response.message;
                    	$scope.dataLoading = false;
                    }
				})
			}

      $scope.$on('$viewContentLoaded', function(){
                $('.top-content').backstretch(
                        ["images/background/1.jpg", "images/background/2.jpg", "images/background/3.jpg"], 
                        {duration: 3000, fade: 750}
                );
                $('.call-to-action-container').backstretch("assets/img/backgrounds/1.jpg");
                $('.testimonials-container').backstretch("assets/img/backgrounds/1.jpg");
                
                $('#top-navbar-1').on('shown.bs.collapse', function(){
                    $('.top-content').backstretch("resize");
                });
                $('#top-navbar-1').on('hidden.bs.collapse', function(){
                    $('.top-content').backstretch("resize");
                });
                
                $('a[data-toggle="tab"]').on('shown.bs.tab', function() {
                    $('.testimonials-container').backstretch("resize");
                });
      });
}]);
'use strict'

angular.module('Authentication').config(["$httpProvider", function ($httpProvider) {        
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
}]).factory('LoginAuthService', ['$http','$cookies','$rootScope', function($http,$cookies,$rootScope){
	var serviceObj = {};

	serviceObj.Login = function (username, password, callback) {

        console.log(username);

    
       var data = {
             user_name:username,
             pass_word:password
            };

        var config = {
         params: data
        };

        
       $http.get('http://localhost:3000/user_login',config).success(function(response) {
           callback(response);
        }).error(function(data, status) {                                            
        alert('Error! ' + status + ' : ' + data)                                  
        })  ;

    };

    serviceObj.SetCredentials = function (username, sessionid) {
          
        $rootScope.globals = {
            currentUser: {
                username: username,
                authdata: sessionid
            }
         };
  
        $http.defaults.headers.common['Authorization'] = 'Basic ' + sessionid; // jshint ignore:line
        $cookies.putObject('globals', $rootScope.globals);

    };
  
    serviceObj.ClearCredentials = function () {
        $rootScope.globals = {};
        $cookies.remove('globals');
        $http.defaults.headers.common.Authorization = 'Basic ';
    };

	return serviceObj;
}]);


(function(){

'use strict'

angular.module('crossOverSmwApp').controller('HomeController', HomeController);

HomeController.$inject = ['$scope','$rootScope','$cookies','UserService'];

	function HomeController($scope, $rootScope,$cookies,UserService){

			$scope.currentUser = "Sandun Priyanka";
			$scope.currentSessionId = null;


			var object = $cookies.getObject('globals').currentUser ;

			$scope.currentUser = object.username;
			$scope.currentSessionId = object.authdata;

			console.log($scope.currentSessionId);


		    UserService.getSalesManData($scope.currentSessionId ,function(response){
			   	if(response.data != null){
					$scope.salesmandata = response.data;
					console.log($scope.salesmandata);
			   	}else{
			   		$scope.error = response.resultDescription;
			   	}
		    });



			UserService.getLastYearData($scope.currentSessionId ,function(response){
			   	if(response.data != null){
					$scope.lastyeardata = response.data;
					console.log($scope.lastyeardata);
			   	}else{
			   		$scope.error = response.resultDescription;
			   	}

			   	console.log($scope.lastyeardata);
		   });

		
		   UserService.getTopSalesOrders($scope.currentSessionId ,function(response){
		   		console.log(response.data);
			   	if(response.data != null){
					$scope.topsalesorder = response.data;
					console.log($scope.topsalesorder);
			   	}else{
			   		$scope.error = response.resultDescription;
			   	}
			   	$scope.salesGroups = $scope.topsalesorder;
			   	console.log($scope.salesGroups);
		   });

		

		
		   UserService.getTopSalesMen($scope.currentSessionId ,function(response){
			   	if(response.data != null){
					$scope.topsalesman = response.data;
					
			   	}else{
			   		$scope.error = response.resultDescription;
			   	}
			    $scope.groups =$scope.topsalesman;
		   });
		   

		$scope.$on('$viewContentLoaded', function(){
			
			FusionCharts.ready(function(){
    			var revenueChart = new FusionCharts({
				        "type": "column2d",
				        "renderAt": "ChartContainer-Line",
				        "width": "500",
				        "height": "300",
				        "dataFormat": "json",
				        "dataSource":  {
				          "chart": {
				            "caption": "Sales Total per month:",
				            "subCaption": "Marble Design Center",
				            "xAxisName": "Month",
				            "yAxisName": "Revenues (In USD)",
				            "theme": "fint"
				         },
				         "data": [
				            {
				               "label": "Jan",
				               "value": "420000"
				            },
				            {
				               "label": "Feb",
				               "value": "810000"
				            },
				            {
				               "label": "Mar",
				               "value": "720000"
				            },
				            {
				               "label": "Apr",
				               "value": "550000"
				            },
				            {
				               "label": "May",
				               "value": "910000"
				            },
				            {
				               "label": "Jun",
				               "value": "510000"
				            },
				            {
				               "label": "Jul",
				               "value": "680000"
				            },
				            {
				               "label": "Aug",
				               "value": "620000"
				            },
				            {
				               "label": "Sep",
				               "value": "610000"
				            },
				            {
				               "label": "Oct",
				               "value": "490000"
				            },
				            {
				               "label": "Nov",
				               "value": "900000"
				            },
				            {
				               "label": "Dec",
				               "value": "730000"
				            }
				          ]
      					}

					 });
				revenueChart.render();
			});

			FusionCharts.ready(function(){
    			var revenueChart = new FusionCharts({
    				    "type": "pie3D",
				        "renderAt": "ChartContainer-Pie",
				        "width": "500",
				        "height": "300",
				        "dataFormat": "json",
				        "dataSource":  {
					    "chart": {
					        "caption": "Sales Total per Sales Man",
					        "palette": "2",
					        "animation": "1",
					        "formatnumberscale": "1",
					        "decimals": "0",
					        "numberprefix": "$",
					        "pieslicedepth": "30",
					        "startingangle": "125",
					        "showborder": "0"
						    },
						    "data": [
						        {
						            "label": "Leverling",
						            "value": "100524",
						            "issliced": "1"
						        },
						        {
						            "label": "Fuller",
						            "value": "87790",
						            "issliced": "1"
						        },
						        {
						            "label": "Davolio",
						            "value": "81898",
						            "issliced": "0"
						        },
						        {
						            "label": "Peacock",
						            "value": "76438",
						            "issliced": "0"
						        },
						        {
						            "label": "King",
						            "value": "57430",
						            "issliced": "0"
						        },
						        {
						            "label": "Callahan",
						            "value": "55091",
						            "issliced": "0"
						        },
						        {
						            "label": "Dodsworth",
						            "value": "43962",
						            "issliced": "0"
						        },
						        {
						            "label": "Suyama",
						            "value": "22474",
						            "issliced": "0"
						        },
						        {
						            "label": "Buchanan",
						            "value": "21637",
						            "issliced": "0"
						        }
						    ]
						}
						});
				revenueChart.render();
			});

        });
	}

})();

'use strict'

angular.module('crossOverSmwApp').config(["$httpProvider", function ($httpProvider) {        
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
}]).factory('UserService', ['$http','$cookies','$rootScope', function($http,$cookies,$rootScope){
		var userserviceObj = {};

	userserviceObj.getSalesManData = function (sessionid,callback) {
		var data = {
             session_id:sessionid,
            };

        var config = {
         params: data
        };

        
       $http.get('http://localhost:3000/sales-man-data',config).success(function(response) {
           callback(response);
        }).error(function(data, status) {                                            
        alert('Error! ' + status + ' : ' + data)                                  
        })  ;

	};

	userserviceObj.getLastYearData = function (sessionid,callback) {
		var data = {
             session_id:sessionid,
            };

        var config = {
         params: data
        };

        
       $http.get('http://localhost:3000/last-year-data',config).success(function(response) {
           callback(response);
        }).error(function(data, status) {                                            
        alert('Error! ' + status + ' : ' + data)                                  
        })  ;
	};

	userserviceObj.getTopSalesOrders = function (sessionid,callback) {
		var data = {
             session_id:sessionid,
            };

        var config = {
         params: data
        };
        
       $http.get('http://localhost:3000/top-sales-orders',config).success(function(response) {
           callback(response);
        }).error(function(data, status) {                                            
        alert('Error! ' + status + ' : ' + data)                                  
        })  ;
	};
	userserviceObj.getTopSalesMen = function (sessionid,callback) {
		var data = {
             session_id:sessionid,
            };

        var config = {
         params: data
        };

        
       $http.get('http://localhost:3000/top-sales-men',config).success(function(response) {
           callback(response);
        }).error(function(data, status) {                                            
        alert('Error! ' + status + ' : ' + data)                                  
        })  ;

	};



	return userserviceObj;
}]);
angular.module('crossOverSmwApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('views/home.html',
    "<div class=\"wz-header-default\"> <div class=\"wz-header-container\"> <div class=\"wz-logo\"> <img id=\"pagelogo\" src=\"images/logo-marble-home.png\" alt=\"\" width=\"200px\" height=\"50px\"> </div> <div class=\"wz-navigation-wrapper\"> <nav class=\"wz-navigation sf-js-enabled sf-arrows\" role=\"navigation\"> <ul class=\"wz-main-menu sf-menu\"> <li class=\"menu-item current\"> <a href=\"#home\">Home</a> </li> <li class=\"menu-item\"> <a href=\"#home\">Menu-Item</a> <ul class=\"sub-menu-items\"> <li> <a href=\"followed.html\">menu item 1</a> </li> <li class=\"current\"> <a href=\"followed.html\">menu item 2</a> </li> </ul> </li> <li class=\"menu-item\"> <a href=\"#home\">Menu-Item</a> </li> <li class=\"menu-item\"> <a href=\"#home\">Menu-Item</a> </li> <li class=\"menu-item\"> <a href=\"#home\">Menu-Item</a> </li> </ul> </nav> <div class=\"loginblock\"> <p style=\"color:#000\">{{currentUser}} logged in!!</p> <p><a href=\"#/login\">Logout</a></p> </div> </div> </div> </div> <div class=\"wz-content-wrapper\"> <div class=\"wz-content\"> <section id=\"wz-content-sec1\"> <div class=\"wz-sec1-container\"> <div class=\"wz-nav-chart-view\"> <div class=\"topleaders\"><h4>Top 5 Sales For The Year</h4><br></div> <div class=\"scroll inside-nav-view\"> <div class=\"nav-chart-lsit-containner\" ng-repeat=\"row in salesGroups\"> <div class=\"media\"> <div class=\"media-left\"> <h3> {{row.orderNum}}<h3> </h3></h3></div> <div class=\"media-body\"> <h5 class=\"media-heading\">{{row.userName}} <span></span> {{row.value}} <h5> {{row.qty}}</h5> </h5></div> </div> </div> </div> </div> <div class=\"wz-chart-view-line\"> <div id=\"ChartContainer-Line\">FusionCharts XT will load here!</div> </div> <div class=\"wz-chart-view-pie\"> <div id=\"ChartContainer-Pie\">FusionCharts XT will load here!</div> </div> </div> </section> <section id=\"wz-content-sec2\"> <div class=\"wz-sec2-container\"> <div class=\"wz-items-wrapper\"> <div class=\"wz-items\"><div class=\"topleaders\"><h4>Top 5 Leaders</h4></div> <div class=\"wz-products columns\" ng-repeat=\"row in groups\"> <div class=\"wz-item-container\"> <div class=\"item-container\"> <div class=\"item-inner-container\"> <div class=\"item-head-image\"> <img src=\"images/{{$index+1}}.jpg\" width=\"150\" height=\"150\"> </div> <div class=\"item-topic-wrapper\"> <div class=\"item-topic\">{{row[0]}}</div> </div> <div class=\"item-content-body\"> <p>{{row[1]}}</p> </div> </div> </div> </div> </div> </div> </div> </div> </section> </div> </div> <div class=\"modal fade\" id=\"supportModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"> <div class=\"modal-dialog\" role=\"document\"> <div class=\"modal-content\"> <div class=\"modal-header\"> <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button> <h4 class=\"modal-title\" id=\"myModalLabel\">Support</h4> </div> <div class=\"modal-body\"> <form role=\"form\"> <div class=\"form-group\"> <label for=\"email\">Subject Text</label> <input type=\"text\" class=\"form-control\" id=\"sub\"> </div> <div class=\"form-group\"> <label for=\"pwd\">Detail Text</label> <input type=\"text\" class=\"form-control\" id=\"content\"> </div> <button type=\"submit\" class=\"btn btn-default\">Send</button> </form> </div> </div> </div> </div> <!-- Modal --> <div class=\"modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\"> <div class=\"modal-dialog\" role=\"document\"> <div class=\"modal-content\"> <div class=\"modal-header\"> <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button> <h4 class=\"modal-title\" id=\"myModalLabel\">Privacy Policy - Terms of Use & Support</h4> </div> <div class=\"modal-body\"> <h6>Terms of Use | Privacy Policy | Marble.Org</h6> <h5> Marble Tile Design Center www.marbles.org Web site Terms Of Use PLEASE REVIEW THESE TERMS OF USE (THE \"TERMS\") FOR FRED HUTCH www.marbles.org WEB SITE (THE \"SITE\"). BY USING THIS SITE, YOU AGREE TO FOLLOW AND BE BOUND BY THE TERMS. IF YOU DO NOT AGREE WITH ANY OF THE TERMS, PLEASE DO NOT USE THIS SITE.</h5> <h6>Unless otherwise expressly noted, you should assume everything you see, hear, or otherwise receive from or on the Site (the \"Content\") is copyright, trademark, trade dress or other intellectual property owned or licensed by Fred Hutch. The Content includes, without limitation, images, illustrations, designs, icons, photographs, trademarks, logos, text, sounds, music, the Site as a whole and any other materials at the Site.</h6> </div> </div> </div> </div> <!--#961313  --> <footer class=\"wz-footer-wrapper\"> <div class=\"policy\"><a data-toggle=\"modal\" data-target=\"#myModal\">Privacy Policy , Terms of Use & Support</a></div> <div class=\"supoort\"><a data-toggle=\"modal\" data-target=\"#supportModal\">Support</a></div> <div id=\"wz-blog-header\"> <div class=\"wz-blog-header-container\"> <div class=\"row\"> <div class=\"col-md-12\"> <h2><img src=\"images/logo-marble-login.png\" alt=\"CAKELABS\" height=\"100\" width=\"300\"><span style=\"font-size: 36px ; font-weight:200\">|</span> DESIGN WORLD</h2> </div> </div> </div> </div> </footer>"
  );


  $templateCache.put('views/login.html',
    "<nav class=\"navbar navbar-inverse navbar-fixed-top navbar-no-bg\" role=\"navigation\"> <div class=\"container\"> <div class=\"navbar-header\"> <img src=\"images/logo-marble-login.png\" alt=\"\" width=\"150px\" height=\"50px\"> </div> <!-- Collect the nav links, forms, and other content for toggling --> <div class=\"collapse navbar-collapse\" id=\"top-navbar-1\"> <ul class=\"nav navbar-nav navbar-right\"> </ul> </div> </div> </nav> <!-- Top content --> <div class=\"top-content\"> <div class=\"inner-bg\"> <div class=\"container\"> <div class=\"row\"> <div class=\"col-sm-5 ebook\"> <img src=\"images/ebook.png\" alt=\"ebook\"> </div> <div class=\"col-sm-7 text\"> <h2 class=\"wow fadeInLeftBig\"> The New Way to Design Your Life </h2> <div class=\"form-box\"> <div class=\"form-top-left\"> <h3 class=\"subtitle\"> Welcome to Marble's World </h3> </div> <div class=\"form-bottom\" style=\"width: 410px\" ng-controller=\"LoginController\"> <form name=\"form\" ng-submit=\"login()\" role=\"form\" class=\"registration-form\"> <div class=\"form-group\"> <label class=\"sr-only\" for=\"username\">User name</label> <input type=\"text\" style=\"width: 350px\" name=\"username\" ng-model=\"username\" placeholder=\"First name...\" class=\"form-first-name form-control\" id=\"form-first-name\"> </div> <div class=\"form-group\"> <label class=\"sr-only\" for=\"password\">Last name</label> <input type=\"password\" style=\"height: 50px  ;width: 350px\" name=\"password\" ng-model=\"password\" placeholder=\"Pass word...\" class=\"form-password form-control\" id=\"form-last-name\"> </div> <button type=\"submit\" style=\"height: 50px  ;width: 350px\" class=\"btn signinbtn\">Sign In</button> </form> </div> </div> </div> </div> </div> </div> </div>"
  );


  $templateCache.put('views/statistics.html',
    "<!DOCTYPE html> <html> <head> <title></title> </head> <body> <div id=\"chart-container\">FusionCharts will render here</div> <script type=\"text/javascript\" src=\"angular.min.js\"></script> <script type=\"text/javascript\" src=\"angular-fusioncharts.min.js\"></script> <script type=\"text/javascript\" src=\"main.js\"></script> </body> </html>"
  );

}]);
