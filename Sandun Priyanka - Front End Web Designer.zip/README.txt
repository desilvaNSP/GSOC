===================================================
CROSS OVER EVALUTION EXAM - SALES MANAGEMENT SYSTEM
===================================================

Used Technologies 

+ Angular JS 
+ Node JS | Express
+ Bower | Grunt
+ JQuery | Less | CSS3

.......................

How to set up project 

1. Firstly run the backend jar

	java -jar backend.jar   | EX : Sanduns-MacBook-Pro:AngularJS Sandun$ java -jar backend.jar

2. After that extract the CrossOver_SMW Zip file and Open the terminal on there.

3. After that run the Server.js as Node command

   node server.js   | EX : Sanduns-MacBook-Pro:CrossOver_SMW Sandun$ node server.js

 4. Then go to the Chrome Browser

 	go to = >  http://localhost:3000/

 5. And you can see simple login page | MARBLE

	Only Predefined users are allowed to login

	Predefined users:[Oswaldo, Mao, Angeline, Gerardo, Nicki,Test]

	Password should be same as user name

6. Have a fun

7. Thank you ...!!! :-)